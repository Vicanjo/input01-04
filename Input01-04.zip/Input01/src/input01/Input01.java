package input01;
import javax.swing.JOptionPane;
public class Input01 {
    public static void main(String[] args) {
        //Create a JOptionPane.
        //Store the input as a String and print it.
        String entrada = JOptionPane.showInputDialog("Escriba un número");
        System.out.println("su número es: " + entrada + "!!");
        
        //Parse the input as an int.
        //Print its value +1
        int num = Integer.parseInt(entrada);
        System.out.println((num + 1) );
        
        //Try creating a dialog, parsing it, and initializing an int in a single line.
        //You should have only one semicolon (;) in this line.
        int num2 = Integer.parseInt(JOptionPane.showInputDialog("escriba un numero x2"));
        System.out.print(num2);
    }
}
