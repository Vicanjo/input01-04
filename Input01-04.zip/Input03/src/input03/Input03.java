package input03;
import java.util.Scanner;
class Input03 {

    public static void main(String[] args) {
        //Create a Scanner
        Scanner en = new Scanner(System.in);
        //Find and print the sum of three integers entered by the user
        System.out.println("Ingrese un número: ");
        int primerNum = en.nextInt();
        System.out.println("Ingrese un número: ");
        int segundoNum = en.nextInt();
        System.out.println("Ingrese un número: ");
        int tercerNum = en.nextInt();
        int suma = primerNum + segundoNum + tercerNum;
        System.out.println("El resultado de la suma es: " + suma);
        //Remember to close the Scanner
        en.close();
    }
}
